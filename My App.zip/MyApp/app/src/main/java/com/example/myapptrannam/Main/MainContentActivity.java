package com.example.myapptrannam.Main;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.example.myapptrannam.R;


public class MainContentActivity extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main_ui);
        initView();
    }

    private void initView() {
        TextView btnGoToJS = findViewById(R.id.js);
        btnGoToJS.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.js:
                Intent intent2 = new Intent();
                intent2.setClass(this, MainJsActivity.class);
                startActivity(intent2);
                break;
            default:
                break;
        }
    }
}
