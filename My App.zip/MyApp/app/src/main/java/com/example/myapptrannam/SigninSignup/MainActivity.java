package com.example.myapptrannam.SigninSignup;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx..activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import com.example.myapptrannam.Main.MainContentActivity;
import com.example.myapptrannam.R;
import com.huawei.hmf.tasks.Task;
import com.huawei.hms.common.ApiException;
import com.huawei.hms.support.account.AccountAuthManager;
import com.huawei.hms.support.account.request.AccountAuthParams;
import com.huawei.hms.support.account.request.AccountAuthParamsHelper;
import com.huawei.hms.support.account.result.AuthAccount;
import com.huawei.hms.support.account.service.AccountAuthService;

import java.net.DatagramPacket;

public class MainActivity<TabLayout> extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG ="MyApp" ;
    AccountAuthParams authParams;
    AccountAuthService authService;
    Button btnHuawei;
    private DatagramPacket result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        signInId();

    }

    @Override
    public void onClick(View view) {


        switch (view.getId()) {
            case R.id.creataccount:
                Intent intent = new Intent();
                intent.setClass(this, SignUpActivity.class);
                startActivity(intent);
                break;
            case R.id.btnsignin:
                Intent intent1 = new Intent();
                intent1.setClass(this, MainContentActivity.class);
                startActivity(intent1);
                break;
            default:
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // Process the authorization result to obtain the authorization code from AuthAccount.
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 8888) {
            Task<AuthAccount> authAccountTask = AccountAuthManager.parseAuthResultFromIntent(data);
            if (authAccountTask.isSuccessful()) {
                // The sign-in is successful, and the user's ID information and authorization code are obtained.
                AuthAccount authAccount = authAccountTask.getResult();
                Log.i(TAG, "serverAuthCode:" + authAccount.getAuthorizationCode());
            } else {
                // The sign-in failed.
                Log.e(TAG, "sign in failed:" + ((ApiException) authAccountTask.getException()).getStatusCode());
            }
        }
    }
    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        doSomeOperations();
                    }
                }
            });

    private void signInId(){
        authParams = new AccountAuthParamsHelper(AccountAuthParams.DEFAULT_AUTH_REQUEST_PARAM).
                setIdToken().setAccessToken().createParams();
        authService= AccountAuthManager.getService(MainActivity.this,authParams);
        signInIDResult.launch(authService.getSignInIntent());
    }


    private void initView() {
        EditText edtUserName = findViewById(R.id.edtusername);
        EditText edtPassword = findViewById(R.id.edtpassword);

        ImageView btnHuawei = findViewById(R.id.huaweisignin);
        btnHuawei.setOnClickListener(this);

        TextView btnCreateAccount= findViewById(R.id.creataccount);
        btnCreateAccount.setOnClickListener(this);

        Button signin = findViewById(R.id.btnsignin);
        signin.setOnClickListener(this);
    }
}



